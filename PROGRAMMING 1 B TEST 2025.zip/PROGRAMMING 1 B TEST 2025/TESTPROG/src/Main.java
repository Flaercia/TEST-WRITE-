import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a Scanner object to read input from the user
        Scanner scanner = new Scanner(System.in);

        // Array of cricketer names
        String[] batsman = {"Jacques Kallis", "Hashim Amla", "AB de Villiers"};
        // Array of stadium names
        String[] stadiums = {"KINGSMEAD", "ST GEORGES", "WANDERERS"};
        // 2D array to store runs scored by each player at each stadium
        int[][] runs = new int[batsman.length][stadiums.length];

        System.out.println("SA CRICKETER APPLICATION");
        System.out.println("*******************************************************************");

        // Nested loop to input runs for each player at each stadium
        for (int j = 0; j < stadiums.length; j++) {
            for (int i = 0; i < batsman.length; i++) {
                System.out.println("Enter the runs scored by " + batsman[i] + " at " + stadiums[j] + ":");
                // Store input in the 2D array
                runs[i][j] = scanner.nextInt();
            }
        }

        // Calculate and output total runs for each stadium
        System.out.println("\n******* TOTAL RUNS STADIUMS *****");
        for (int j = 0; j < stadiums.length; j++) {
            // Initialize total runs for this stadium
            int totalStadium = 0;

            // Sum runs of all players at the current stadium
            for (int i = 0; i < batsman.length; i++) {
                totalStadium += runs[i][j];
            }

            // Print the total runs for this stadium
            System.out.println(stadiums[j] + " : " + totalStadium);
        }

        // Close the scanner to avoid memory leaks
        scanner.close();
    }
}
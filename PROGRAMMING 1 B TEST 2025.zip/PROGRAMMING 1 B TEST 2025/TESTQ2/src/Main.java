import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a Scanner object to read input from the user
        Scanner scanner = new Scanner(System.in);

        // Prompt the user with the cricketer's name
        System.out.println("The cricketer name: Jacques Kallis");
        // Read the name input (even though it's prefilled in the prompt)
        String name = scanner.nextLine();

        // Ask the user to enter the stadium where the match was played
        System.out.println("Enter the stadium: ");
        String stadium = scanner.nextLine();

        // Ask the user to enter the total runs scored by Jacques Kallis at Wanderers
        System.out.println("Enter the total runs scored by Jacques Kallis at Wanderers: ");
        int runs = scanner.nextInt();

        // Close the scanner to avoid memory leaks
        scanner.close();

        // Create an instance of the CricketRunsScored class with the collected data
        CricketRunsScored scored = new CricketRunsScored(name, stadium, runs);

        // Call the PrintReport method to display the report on the console
        scored.PrintReport();
    }
}


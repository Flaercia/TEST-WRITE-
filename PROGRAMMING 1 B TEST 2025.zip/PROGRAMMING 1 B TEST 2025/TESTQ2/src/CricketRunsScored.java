
public class CricketRunsScored extends Cricket {

    // Constructor: receives the cricketer's name, stadium, and runs
    // Passes these values to the parent class (Cricket) using 'super'
    public CricketRunsScored(String name, String stadium, int runs){
        super(name, stadium, runs);
    }

    // This method prints a simple report of the cricketer's performance
    public void PrintReport(){
        System.out.println("BATSMAN RUNS SCORED REPORT");  // Header for the report
        // Prints the player's name (using getName() from the parent class)
        System.out.println("CRICKET PLAYER: Jacques Kallis " + getName());
        // Prints the stadium name (using getStadium() from the parent class)
        System.out.println("STADIUM: " + getStadium());
    }
}
public interface ICricket {
    String getName();
    String getStadium();
    int getRuns();
}

public class Cricket implements ICricket {
    // Private variables to store the cricketer's name, stadium, and runs scored
    private String name;
    private String stadium;
    private int runs;

    // Constructor to initialize the cricketer's name, stadium, and runs
    public Cricket(String name, String stadium, int runs) {
        this.name = name;       // Store the cricketer's name
        this.stadium = stadium; // Store the stadium name
        this.runs = runs;       // Store the runs scored (fixed!)
    }

    // Getter method for the cricketer's name
    public String getName() {
        return name;
    }

    // Getter method for the stadium
    public String getStadium() {
        return stadium;
    }

    // Getter method for the runs scored
    public int getRuns() {
        return runs;
    }
}